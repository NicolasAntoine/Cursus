#ifndef BLOCK_H
#define BLOCK_H

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//bloc est une matrice de n elements avec x elements dedans qui sont toujours du même nombre
char * block_to_string(uint8_t** block, int size){
    char * s = (char *)malloc(size*4);
    if (s == NULL){
        printf("Error malloc block_to_string");
        exit(EXIT_FAILURE);
    }
    int index = 0;
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < 4; j++) {
            if (block[i][j] == 0) {
                s[index] = '\0';
                return s;
            }
            s[index] = (char) block[i][j];
            index ++;
        }
    }
    s[index] = '\0';
    return s;
}

void write_block(FILE* outputFile, uint8_t **block, uint32_t size, uint32_t word_size ){
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < word_size; j++)
        {
            fwrite(&block[i][j],1,1,outputFile);
        }
    }
}

void write_last_block(FILE* outputFile, uint8_t **block, uint32_t size, uint32_t word_size ,uint32_t last_word_size){
    for (int i = 0; i < size-1; i++)
    {
        for (int j = 0; j < word_size; j++)
        {
            fwrite(&block[i][j],1,1,outputFile);
        }
    }
    
    for (int i = 0; i < last_word_size ; i++) {
        fwrite(&block[size-1][i],1,1,outputFile);
    }
}

#endif /* SYSTEM_H */
