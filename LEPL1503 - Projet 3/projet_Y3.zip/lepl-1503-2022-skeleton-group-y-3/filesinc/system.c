#ifndef SYSTEM_H
#define SYSTEM_H

#include <stdint.h>
#include "../headers/gf256_tables.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../headers/tinymt32.h"

extern uint8_t ** coeffs;

/**
 *
 * Add two vectors in a Galois Field 256
 * @param symbol_1: the first symbol to add
 * @param symbol_2: the second symbol to add
 * @param symbol_size: size of the two symbols (of the same size!)
 * @return: a new vector of `symbol_size` byte containing the result of symbol_1 + symbol_2 in GF(256)
 */
uint8_t *gf_256_full_add_vector(uint8_t *symbol_1, uint8_t *symbol_2, uint32_t symbol_size) {
    uint8_t *symbols = malloc(sizeof(uint8_t)*symbol_size);
    if (symbols == NULL){
        printf("Error malloc full_add_vector");
    }
    for (int i = 0; i<symbol_size; i++) {
        symbols[i] = (symbol_1[i])^(symbol_2[i]);
    }
    return symbols;
}

/**
 *
 * Multiply a vector by a coefficient in a Galois Field 256
 * @param symbol: the symbol to multiply
 * @param coef: the coefficient of the scaling
 * @param symbol_size: size of the symbol
 * @return: a new vector of `symbol_size` byte containing the result of symbol * coef in GF(256)
 */
uint8_t *gf_256_mul_vector(uint8_t *symbol, uint8_t coef, uint32_t symbol_size) {
    uint8_t *symbols = malloc(sizeof(uint8_t)*symbol_size);
    
    if (symbols == NULL) {
        printf("Error malloc mul_vector");
        return 0;
    }
    for (int i = 0; i<symbol_size; i++) {
        symbols[i] = gf256_mul_table[symbol[i]][coef];
    }
    return symbols;
}

/**
 *
 * Divide a vector in a Galois Field 256 by a coefficient
 * @param symbol: the symbol to add
 * @param coef: the dividing coefficient
 * @param symbol_size: size of the two symbols (of the same size!)
 * @return: a new vector of `symbol_size` byte containing the result of symbol / coef in GF(256)
 */
uint8_t *gf_256_inv_vector(uint8_t *symbol, uint8_t coef, uint32_t symbol_size) {
    uint8_t *symbols = malloc(sizeof(uint8_t)*symbol_size);
    if (symbols == NULL){
        printf("Error malloc inv_vector");
        return 0;
    }
    for (int i = 0; i<symbol_size; i++) {
        symbols[i] = gf256_mul_table[symbol[i]][gf256_inv_table[coef]];
    }
    return symbols;
}

/**
 *
 * Resolve the linear system Ax=b in a Galois Field 256. The result is stored in the independent terms after the resolution
 * @param A: matrix of coefficients
 * @param b: independent terms
 * @param symbol_size: size of the independent terms
 * @param system_size: the size of the system (i.e., number of rows/columns)
 */
void gf_256_gaussian_elimination(uint8_t **A, uint8_t **b, uint32_t symbol_size, uint32_t system_size) {
    
    for (int k = 0; k<system_size ; k++) {
        for (int i = k+1; i < system_size; i++) {
            uint8_t factor = gf256_mul_table[A[i][k]][gf256_inv_table[A[k][k]]];
            for (int j = 0; j<system_size; j++) {
                A[i][j] = A[i][j]^gf256_mul_table[A[k][j]][factor]; //bizarre de devoir cast
            }
            b[i] = gf_256_full_add_vector(b[i], gf_256_mul_vector(b[k], factor, symbol_size), symbol_size); //à vérif les arguments size
        }
    }
    uint8_t* factor_tab;
    for(int i = system_size-1; i>=0;i--) {
        factor_tab = calloc(symbol_size,sizeof(uint8_t));
        if (factor_tab == NULL){
            printf("Error calloc factor_tab");
            exit(EXIT_FAILURE);
        }
        for(int j = i+1; j<system_size;j++) {
            factor_tab = gf_256_full_add_vector(factor_tab, gf_256_mul_vector(b[j], A[i][j], symbol_size), symbol_size);
        }
        b[i] = gf_256_inv_vector(gf_256_full_add_vector(b[i], factor_tab, symbol_size), A[i][i], symbol_size);
    }
    free(factor_tab);
}

/**
 *
 * Generate all coefficients for a block
 * @param seed: the seed to generate the coefficients
 * @param nss: number of source symbols in a block
 * @param nrs: number of repair symbols in a block
 * @return: a nss * nrs array of coefficients
 */
uint8_t **gen_coefs(uint32_t seed, uint32_t redun, uint32_t size){
    uint8_t ** coeff = malloc(sizeof(uint8_t *)*redun);
    if (coeff == NULL){
        printf("Error malloc gen_coefs");
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < redun; i++)
    {
        coeff[i] = malloc(sizeof(uint8_t)*size);
    }
    tinymt32_t prng ;
    memset(&prng , 0, sizeof (tinymt32_t)) ;
    prng.mat1 = 0x8f7011ee;
    prng.mat2 = 0xfc78ff1f;
    prng.tmat = 0x3793fdff;
    tinymt32_init(&prng, seed);

    for (int i = 0; i < redun; i++)
    {
        for (int j = 0; j < size; j++)
        {
            coeff[i][j] =(uint8_t) tinymt32_generate_uint32(&prng);
            if (coeff[i][j] == 0)
            {
                coeff[i][j] = 1;
            }   
        }
    }
    return coeff;
}

#endif /* SYSTEM_H */
