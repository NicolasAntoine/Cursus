#ifndef BLOCK_H
#define BLOCK_H

typedef struct
{
    // TODO
} block_t;

#endif /* BLOCK_H */