#ifndef MESSAGE_H
#define MESSAGE_H

typedef struct
{
    // TODO
} message_t;

#endif /* MESSAGE_H */