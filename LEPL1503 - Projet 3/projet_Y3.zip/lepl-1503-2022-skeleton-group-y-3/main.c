#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <dirent.h>
#include <errno.h>
#include <getopt.h>
#include <limits.h>
#include <inttypes.h>
#include <stdbool.h>
#include <math.h>
#include "headers/tinymt32.h"
#include "headers/portable_endian.h"
#include "filesinc/system.c"
#include "filesinc/block.c"

typedef struct
{
    DIR *input_dir;
    char input_dir_path[PATH_MAX];
    FILE *output_stream;
    uint8_t nb_threads;
    bool verbose;
} args_t;


//structure qui va permettre d'avoir le nombre d'inconnues et l'index des inconnues
typedef struct
{
    uint32_t * unknown_indexes;
    uint32_t uknown_count;
} unknow_t;


//strcuture qui va nous permettre d'avoir la matrice A, la matrice B, symbol size
// et system_size
typedef struct
{
    uint8_t ** A;
    uint8_t ** B;
    uint32_t ligne;
    uint32_t colonne;
} linear_t;


//les données du fichier dans les 24 premiers bits
uint32_t seed;
uint32_t block_size;
uint32_t word_size;
uint32_t redundancy;
uint64_t message_size; 


//le coefficient à générer
uint8_t ** coeffs;

void usage(char *prog_name)
{
    fprintf(stderr, "USAGE:\n");
    fprintf(stderr, "    %s [OPTIONS] input_dir\n", prog_name);
    fprintf(stderr, "    input_dir: path to the directory containing the instance files with the encoded messages\n");
    fprintf(stderr, "    -f output_file: path to the output file containing all decoded messages\n");
    fprintf(stderr, "    -n n_threads (default: 4): set the number of computing threads that will be used to execute the RLC algorithm\n");
    fprintf(stderr, "    -v : enable debugging messages. If not set, no such messages will be displayed (except error messages on failure)\n");
}

int parse_args(args_t *args, int argc, char *argv[])
{
    memset(args, 0, sizeof(args_t));

    // Default values of the arguments
    args->nb_threads = 4;
    args->verbose = false;
    args->output_stream = stdout;

    int opt;
    while ((opt = getopt(argc, argv, "n:vf:")) != -1)
    {
        switch (opt)
        {
        case 'n':
            args->nb_threads = atoi(optarg);
            if (args->nb_threads == 0)
            {
                fprintf(stderr, "The number of computing threads must be a positive integer, got: %s\n", optarg);
                return -1;
            }
            break;
        case 'v':
            args->verbose = true;
            break;
        case 'f':
            args->output_stream = fopen(optarg, "wb");
            if (args->output_stream == NULL)
            {
                fprintf(stderr, "Impossible to open the output file %s: %s\n", optarg, strerror(errno));
                return -1;
            }
            break;
        case '?':
            usage(argv[0]);
            return 1;
        default:
            usage(argv[0]);
        }
    }

    if (optind == argc)
    {
        fprintf(stderr, "You must provide an input directory containing the instance files!\n");
        return -1;
    }

    // Source: https://stackoverflow.com/questions/11736060/how-to-read-all-files-in-a-folder-using-c
    if (NULL == (args->input_dir = opendir(argv[optind])))
    {
        fprintf(stderr, "Impossible to open the directory containing the input instance files %s: %s\n", argv[optind], strerror(errno));
        return -1;
    }
    // The following line is not very secure... Ask Prof. Legay and/or wait for LINGI2144 for more information :-)
    strcpy(args->input_dir_path, argv[optind++]);

    return 0;
}




//fonction make liner qui construit un système linaire Ax=b
linear_t * make_linear_system(uint32_t *unknown_index, uint32_t nbr_unknown,uint8_t ** current_block, uint32_t bloc_size){
    
    //creer la structure afin de mettre A, B, symbol_size et system_size
    linear_t *linear = malloc(sizeof(linear_t));
    if (linear == NULL){
        printf("Error malloc make_linear_system for *linear ");
        exit(EXIT_FAILURE);
    }
    linear->colonne = nbr_unknown;
    linear->ligne = nbr_unknown * word_size;

    linear->A = malloc(sizeof(uint8_t *)*nbr_unknown);
    if(linear->A == NULL){
        printf("Error malloc make_linear_system fir linear->A");
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < nbr_unknown; i++){
        linear->A[i] = malloc(sizeof(uint8_t)*nbr_unknown);
        if(linear->A[i] == NULL){
            printf("Error malloc make_linear_system fir linear->A[i]");
            exit(EXIT_FAILURE);
        }

    }
 
    linear->B = malloc(sizeof(uint8_t *)*nbr_unknown);
    if (linear->B == NULL){
        printf("Error malloc make_linear_system fir linear->B");
        exit(EXIT_FAILURE);
    }


    for (int i = 0; i < nbr_unknown; i++){
        linear->B[i] = malloc(sizeof(uint8_t)*word_size);
        if (linear->B[i] == NULL){
            printf("Error malloc make_linear_system fir linear->B[i]");
            exit(EXIT_FAILURE);
        }
        linear->B[i] = current_block[bloc_size+i];
    }
    for (int i = 0; i < nbr_unknown; i++){
        int tmp = 0;
        for (int j = 0; j < bloc_size; j++){
            if (unknown_index[j] == 1){
                linear->A[i][tmp] = coeffs[i][j];
                tmp ++;
            }else{
    
                linear->B[i] = gf_256_full_add_vector(linear->B[i],gf_256_mul_vector(current_block[j],
                coeffs[i][j],linear->ligne),linear->ligne);
            }}}
    return linear;
}

//Construire un bloc qur base des données et de la taille d'un bloc
uint8_t ** make_block(uint8_t *data,uint32_t size){


    uint8_t  ** block = malloc(sizeof(uint8_t *)*(size+redundancy));
    if (block == NULL){
        printf("Error malloc make_block for block**");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < size+redundancy; i++)
    {
        block[i] = malloc(sizeof(uint8_t)*word_size);
        if (block[i] == NULL)
        {
            printf("Error malloc make_block for block[i]");
            exit(EXIT_FAILURE);
        }
        
    }

    for (int i = 0; i < size+redundancy; i++)
    {
        for (int j = 0; j < word_size; j++)
        {
            block[i][j] = data[i * word_size +j];
        }
    }
    return block;
}

// Sur base d'un bloc, trouve les symboles sources perdus et les répertorie dans `unknown_indexes`.
// Un symbole est considéré comme perdu dans le bloc si le symbole ne contient que des 0
unknow_t *find_lost_words(uint8_t ** block,uint32_t size){
   unknow_t *answer = malloc(sizeof(unknow_t));
   if (answer == NULL){
       printf("Error malloc find_lost_words for *answer");
        exit(EXIT_FAILURE);
   }
   answer->unknown_indexes = malloc(sizeof(uint32_t)*size);
   if (answer->unknown_indexes == NULL){
       printf("Error malloc find_lost_words for answer->unknow_index");
    exit(EXIT_FAILURE);
   }
   answer->uknown_count = 0;
   for (int i = 0; i < size; i++)
   {
       answer->unknown_indexes[i] = 0;
   }
   for (int i = 0; i < size; i++)
   {
       uint32_t count = 0;
       for (int j = 0; j < word_size; j++)
       {           
           count += block[i][j];
       }
       if (count == 0){  
            answer->unknown_indexes[i] = 1;
            answer->uknown_count +=1;
   }}
   return answer;
}

// Sur base d'un bloc, trouve les inconnues (i.e., symboles sources perdus) et construit le système linéaire
// correspondant. Cette version simple considère qu'il y a toujours autant d'inconnues que de symboles de redondance,
// c'est-à-dire qu'on va toujours construire un système avec autant d'équations que de symboles de redondances.
uint8_t ** process_block(uint8_t ** block,uint8_t size){
    unknow_t *unknow = find_lost_words(block,size);
    if (unknow->uknown_count != 0){
    linear_t *linear = make_linear_system(unknow->unknown_indexes,unknow->uknown_count,block, size);
    gf_256_gaussian_elimination(linear->A,linear->B,linear->ligne,linear->colonne);
    int temp = 0;
    for (int i = 0; i < size; i++)
    {
       if (unknow->unknown_indexes[i] == 1)
       {
           block[i] = linear->B[temp];
           temp ++;
       }
    }}
    
    return block;
}

uint8_t * copytable(int from, int to, uint8_t * table){
    uint8_t * answer = malloc(sizeof(uint8_t)*(to - from));
    if (answer == NULL){
        printf("Error malloc copytable for *answer");
        exit(EXIT_FAILURE);
    }
    for (int i = 0; i < (to - from); i++)
    {
        answer[i] = table[i+from];
    }
    return answer;
}

int main(int argc, char *argv[])
{

    
    args_t args;
    int err = parse_args(&args, argc, argv);
    if (err == -1)
    {
        exit(EXIT_FAILURE);
    }
    else if (err == 1)
    {
        exit(EXIT_SUCCESS);
    }


    // The following lines (and every code already present in this skeleton) can be removed, it is just an example to show you how to use the program arguments
    fprintf(stderr, "\tnumber of threads executing the RLC decoding algorithm in parallel: %" PRIu32 "\n", args.nb_threads);
    fprintf(stderr, "\tverbose mode: %s\n", args.verbose ? "enabled" : "disabled");

    //ouvrir le fichier à lire
   struct dirent *directory_entry;
    FILE *input_file;
    
    //ouvrir le fichier où écrire le message décodé
    args.output_stream = fopen(argv[2],"wb");
    while ((directory_entry = readdir(args.input_dir)))
    {
        // Ignore parent and current directory
        if (!strcmp(directory_entry->d_name, "."))
        {
            continue;
        }
        if (!strcmp(directory_entry->d_name, ".."))
        {
            continue;
        }

        // Add the directory path to the filename to open it
        char full_path[PATH_MAX];
        memset(full_path, 0, sizeof(char) * PATH_MAX);
        strcpy(full_path, args.input_dir_path);
        strcat(full_path, "/");
        strcat(full_path, directory_entry->d_name);

        input_file = fopen(full_path, "rb");
        if (input_file == NULL)
        {
            fprintf(stderr, "Failed to open the input file %s: %s\n", full_path, strerror(errno));
            goto file_read_error;
        }

        if (args.verbose)
        {
            fprintf(stderr, "Successfully opened the file %s\n", full_path);
        }
        
    
    //Récupérer les informations qui se situent sur les 24 premiers bytes
    uint32_t *buffer = malloc(sizeof(uint32_t)*6); // Buffer to store data
    if (buffer == NULL){
        printf("Error malloc in main for buffer");
        exit(EXIT_FAILURE);
    }
    fread(buffer, sizeof(uint32_t), 6, input_file); 
    seed = be32toh(*((uint32_t *) buffer)); //element 0 --> seed
    block_size= be32toh(*((uint32_t *) buffer+1)); // element 1 --> block size
    word_size = be32toh(*((uint32_t *) buffer+2)); // element 2 --> word_size
    redundancy = be32toh(*((uint32_t *) buffer+3)); // element 3 --> redundancy
    message_size = be32toh(*((uint32_t *) buffer + 5));  //element 4-5 --> message_size car 8 bits au lieu de 4
    //free le buffer car on en a plus besoin, toutes les variables sont attribuées
    free(buffer);

    //avoir la taille du fichier
	fseek(input_file, 0, SEEK_END);
	int fileLen=ftell(input_file);
	fseek(input_file, 0, SEEK_SET);
    //mettre -24 car les 24 premier bits ne seront pas utiliser
    fileLen = fileLen-24;

    //allouer de la mémoire pour les caractères du fichier
    uint8_t * binary_data = malloc(fileLen);
    if (binary_data == NULL)
    {
        printf("Error malloc int main for binary_data");
        exit(EXIT_FAILURE);
    }
    

    //passer les 24 premiers bits avec que le len soit correct
    fread(binary_data, 24,1,input_file);
    //avoir les bits de [24:filenLen]
    fread(binary_data, 1,fileLen,input_file);

    //générer lees coefficients
    coeffs = gen_coefs(seed,redundancy,block_size);
    uint32_t step = word_size * (redundancy +block_size);

    //écrire au début du fichier la longueur du fichier, le message size et le nom
    // du fichier
    int lenFileName = strlen(directory_entry->d_name);
    fwrite(&lenFileName,4,1,args.output_stream);
    fwrite(&message_size,8,1, args.output_stream);
    fwrite(&directory_entry->d_name,lenFileName,1,args.output_stream);

    
    //arrondir vers le haut le nombre de block qu'il y aura
    uint32_t nb_block = ceil((float)fileLen/(word_size *(block_size + redundancy)));
    int incomplete_block = 0;
    //savoir s'il y a des blocs incomplets
    if (message_size != nb_block * block_size * word_size){
        nb_block--;
        incomplete_block = 1;
    }

    int readed = 0;
    //Ecrire dans l'output tous les blocs sauf le dernier s'il est incomplet.
    //Si le dernier bloc est complet, on utilsera cette fonction pour finir d'écrire dans le fichier.
    for (int i = 0; i < nb_block; i++)
    {
        uint8_t * tab = copytable(i*step,(i+1)*step,binary_data);
        uint8_t ** current_block = make_block(tab,block_size);
        uint8_t ** response = process_block(current_block,block_size);
        write_block(args.output_stream,response,block_size,word_size);
        readed += step;
        
    }
    
    int readed_symbols = block_size * word_size * nb_block;
    int nb_remaining_symbols = (floor(fileLen - readed)/word_size)-redundancy;

    //Ecrire le dernier bloc s'il est incomplet
    if (incomplete_block == 1){
        uint8_t ** last_block = make_block(copytable(readed,fileLen,binary_data),nb_remaining_symbols);
        uint8_t ** decoded = process_block(last_block,nb_remaining_symbols); 
        int padding = readed_symbols + nb_remaining_symbols * word_size - message_size;
        int true_length_last_symbol = word_size - padding;
        write_last_block(args.output_stream, decoded, nb_remaining_symbols, word_size, true_length_last_symbol);
    }

    

        
        if (args.verbose)
        {
            printf("Coefficient: %u\n", coeffs[0][0]);
        }
         // Close this instance file
        free(binary_data);
        fclose(input_file);
        
        
    }
    // Close the input directory and the output file
    err = closedir(args.input_dir);
    if (err < 0)
    {
        fprintf(stderr, "Error while closing the input directory containing the instance files\n");
    }
    if (args.output_stream != stdout)
    {
        fclose(args.output_stream);
    }
    return 0;

file_read_error:
    err = closedir(args.input_dir);
    if (err < 0)
    {
        fprintf(stderr, "Error while closing the input directory containing the instance files\n");
    }
    if (args.output_stream != stdout)
    {
        fclose(args.output_stream);
    }
    exit(EXIT_FAILURE);
}
