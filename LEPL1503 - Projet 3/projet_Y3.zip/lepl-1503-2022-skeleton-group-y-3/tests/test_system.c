#include <CUnit/Basic.h>
#include "../filesinc/system.c"
#include <stdlib.h>
#include <stdio.h>

//gcc -o system tests/test_system.c -lcunit
//./system

void test_assert_fulladd(void) {
    uint8_t *frst = malloc(sizeof(uint8_t));
    if (frst == NULL){
        printf("Error first malloc test_assert_fulladd");
        exit(EXIT_FAILURE);}
    *frst = 1;
    uint8_t *scnd = malloc(sizeof(uint8_t));
    if (scnd == NULL){
        printf("Error second malloc test_assert_fulladd");
        exit(EXIT_FAILURE);}
    *scnd = 1;
    uint8_t *adder = gf_256_full_add_vector(frst, scnd, 1);
    CU_ASSERT_EQUAL(adder[0], 0);
    free(frst);
    free(scnd);
}

void test_assert_mul(void) {
    uint8_t *first = malloc(sizeof(uint8_t)*3);
    if (first == NULL){
        printf("Error malloc test_assert_mul");
        exit(EXIT_FAILURE);}
    first[0] = 1;
    first[1] = 0;
    first[2] = 0;
    uint8_t *multi = gf_256_mul_vector(first, 5, 1);
    CU_ASSERT_EQUAL(multi[1], 0);
    free(first);
}

void test_assert_inv(void) {
    uint8_t *first = malloc(sizeof(uint8_t));
    if (first == NULL){
        printf("Error malloc test_assert_inv");
        exit(EXIT_FAILURE);}
    *first = 1;
    uint8_t *inv = gf_256_inv_vector(first, 5, 1); 
    CU_ASSERT_EQUAL(inv[0], 167);
    free(first);
}
void test_assert_gauss(void) {
    uint8_t **A = malloc(sizeof(uint8_t)*1);
    if (A == NULL){
        printf("Error first malloc test_assert_gauss");
        exit(EXIT_FAILURE);}
    for (size_t i = 0; i < 1; i++)
    {
        A[i] = malloc(sizeof(u_int8_t)*1);
    }
    A[0][0] = 171;
    uint8_t **b = malloc(sizeof(uint8_t)*1);
    for (size_t i = 0; i < 1; i++) {
    if (b == NULL){
        printf("Error second malloc test_assert_gauss");
        exit(EXIT_FAILURE);}}
    for (size_t i = 0; i < 1; i++)
    {
        b[i] = malloc(sizeof(uint8_t)*3);
    }
    b[0][0] = 189;
    b[0][1] = 39;
    b[0][2] = 196;
    gf_256_gaussian_elimination(A, b, 8, 1);
    /*printf("%d\n",b[0][0]);
    printf("%d\n",b[0][1]);
    printf("%d\n",b[0][2]);
    printf("\n");*/
    CU_ASSERT_EQUAL(b[0][0], 110);
    CU_ASSERT_EQUAL(b[0][1], 103);
    CU_ASSERT_EQUAL(b[0][2], 32);
    free(A);
    free(b);
}

void test_assert_gauss1(void) {
    uint8_t **A = malloc(sizeof(uint8_t*)*2);
    if (A == NULL){
        printf("Error first malloc test_assert_gauss1");
        exit(EXIT_FAILURE);}
    for (size_t i = 0; i < 2; i++)
    {
        A[i] = malloc(sizeof(u_int8_t)*2);
    }
    A[0][0] = 171;
    A[0][1] = 55;
    A[1][0] = 61;
    A[1][1] = 143;
    uint8_t **b = malloc(sizeof(uint8_t*)*2);
    if (b == NULL){
        printf("Error second malloc test_assert_gauss1");
        exit(EXIT_FAILURE);}
    for (size_t i = 0; i < 2; i++)
    {
        b[i] = malloc(sizeof(uint8_t)*3);
    }
    b[0][0] = 161;
    b[0][1] = 220;
    b[0][2] = 88;
    b[1][0] = 3;
    b[1][1] = 31;
    b[1][2] = 57;
    gf_256_gaussian_elimination(A, b, 8, 2);
    /*printf("%d\n",b[0][0]);
    printf("%d\n",b[0][1]);
    printf("%d\n",b[0][2]);
    printf("%d\n",b[1][0]);
    printf("%d\n",b[1][1]);
    printf("%d\n",b[1][2]);
    printf("\n");*/
    CU_ASSERT_EQUAL(b[0][0], 73);
    CU_ASSERT_EQUAL(b[0][1], 32);
    CU_ASSERT_EQUAL(b[0][2], 108);
    CU_ASSERT_EQUAL(b[1][0], 32);
    CU_ASSERT_EQUAL(b[1][1], 67);
    CU_ASSERT_EQUAL(b[1][2], 32);
    free(A);
    free(b);
}

void test_assert_gauss2(void) {
    uint8_t **A = malloc(sizeof(uint8_t*)*2);
    if (A == NULL){
        printf("Error first malloc test_assert_gauss2");
        exit(EXIT_FAILURE);}
    for (size_t i = 0; i < 2; i++)
    {
        A[i] = malloc(sizeof(u_int8_t*)*2);
    }
    A[0][0] = 171;
    A[0][1] = 55;
    A[1][0] = 61;
    A[1][1] = 143;
    uint8_t **b = malloc(sizeof(uint8_t*)*2);
    if (b == NULL){
        printf("Error second malloc test_assert_gauss2");
        exit(EXIT_FAILURE);}
    for (size_t i = 0; i < 2; i++)
    {
        b[i] = malloc(sizeof(uint8_t)*3);
    }
    b[0][0] = 146;
    b[0][1] = 217;
    b[0][2] = 107;
    b[1][0] = 42;
    b[1][1] = 80;
    b[1][2] = 157;
    gf_256_gaussian_elimination(A, b, 8, 2);
    /*printf("%d\n",b[0][0]);
    printf("%d\n",b[0][1]);
    printf("%d\n",b[0][2]);
    printf("%d\n",b[1][0]);
    printf("%d\n",b[1][1]);
    printf("%d\n",b[1][2]);
    printf("\n");*/
    CU_ASSERT_EQUAL(b[0][0], 112);
    CU_ASSERT_EQUAL(b[0][1], 114);
    CU_ASSERT_EQUAL(b[0][2], 111);
    CU_ASSERT_EQUAL(b[1][0], 109);
    CU_ASSERT_EQUAL(b[1][1], 109);
    CU_ASSERT_EQUAL(b[1][2], 105);
    free(A);
    free(b);
}

int main() {
    CU_initialize_registry();
    CU_pSuite suite = CU_add_suite("system", 0, 0);

    CU_add_test(suite, "fulladd test", test_assert_fulladd);
    CU_add_test(suite, "mult test", test_assert_mul);
    CU_add_test(suite, "inv test", test_assert_inv);
    CU_add_test(suite, "gauss test 1", test_assert_gauss);
    CU_add_test(suite, "gauss test 2", test_assert_gauss1);
    CU_add_test(suite, "gauss test 3", test_assert_gauss2);
    
    CU_basic_run_tests();
    CU_basic_show_failures(CU_get_failure_list());
}
