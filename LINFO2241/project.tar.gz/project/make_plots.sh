#!/usr/bin/bash
echo "Wow ! Don't just execute random scripts from the internet are you crazy ?"
echo "By the way this is where the scripts that runs your experiments and plots your data should go ! :)"