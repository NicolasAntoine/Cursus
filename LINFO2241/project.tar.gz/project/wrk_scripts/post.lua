wrk.method = "POST"
wrk.body = "8,16,1,1So4BA8QEeuKeKAykWviFOyI"
wrk.headers["Content-Type"] = "application/x-www-form-urlencoded"
